package org.app.mutualAuthTwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MutualAuthTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MutualAuthTwoApplication.class, args);
	}

}
