package org.app.myappbymicro;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/data")
public class MyappbymicroRestApplication extends Application {
}
