package org.app.mutualAuthOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MutualAuthOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(MutualAuthOneApplication.class, args);
	}

}
