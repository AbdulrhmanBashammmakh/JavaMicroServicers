package org.app.mutualAuthOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MutualAuthOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
